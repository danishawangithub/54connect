import React, { Component } from "react";
import Slider from 'react-slick';
import {useState ,useEffect, useRef} from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Link from '../components/Link';
 
 
function Profile(){
   
 
  return (
      
      <>
          
      </>

  );
}

export default Profile;