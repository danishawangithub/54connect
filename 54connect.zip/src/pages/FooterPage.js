import React  from 'react';
import Footer from '../components/Footer';

function FooterPage() {

      return(

            <Footer />
         );
}

export default FooterPage; 
