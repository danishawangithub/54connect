import React  from 'react';

import Header from '../components/Header';
function HeaderPage() {

      return(

            <Header />
         );
}

export default HeaderPage; 
