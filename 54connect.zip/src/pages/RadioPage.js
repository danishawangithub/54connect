import React  from 'react';
import Radio from '../components/Radio';

function RadioPage() {

 
      return(

            <Radio />
         );
}

export default RadioPage; 
