import React  from 'react';
import Tv_live from '../components/Tv_live';
function Tv_livePage() {

 
      return(

            <Tv_live />
         );
}

export default Tv_livePage; 
