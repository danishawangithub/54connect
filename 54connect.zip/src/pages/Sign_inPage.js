import React  from 'react';
import Sign_in from '../components/Sign_in';

function Sign_inPage() {

 
      return(

            <Sign_in />
         );
}

export default Sign_inPage; 
