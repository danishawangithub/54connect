import React  from 'react';
import I_witness from '../components/I_witness';

function I_witnessPage() {

 
      return(

            <I_witness />
         );
}

export default I_witnessPage; 
