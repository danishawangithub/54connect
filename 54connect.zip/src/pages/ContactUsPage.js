import React,{useState} from 'react';
import ContactUs from '../components/ContactUs';

function ContactUsPage() {
 
    
   
      return(

            <ContactUs  />
         );
}

export default ContactUsPage; 
