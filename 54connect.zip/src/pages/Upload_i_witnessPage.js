import React  from 'react';
import Upload_i_witness from '../components/Upload_i_witness';

function Upload_i_witnessPage() {

 
      return(

            <Upload_i_witness />
         );
}

export default Upload_i_witnessPage; 
